export class Citalac
{
    constuctor(ID,Ime,ImeRoditelja,Prezime,BrojTelefona)
    { this.ID = ID;
        this.Ime = Ime;
        this.ImeRoditelja = ImeRoditelja;
        this.Prezime = Prezime;
        this.BrojTelefona = BrojTelefona;
    }
}
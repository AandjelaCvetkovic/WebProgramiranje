export class Knjiga
{
    constructor(ID, Naslov, ImePisca, Tip)
    {
        this.ID = ID;
        this.Naslov = Naslov;
        this.ImePisca = ImePisca;
        this.Tip = Tip;
     //   this.Dostupna = null;
     //   this.DostupnoNaStanju = 0;
      //  this.listaCitalaca = [];
    }
}
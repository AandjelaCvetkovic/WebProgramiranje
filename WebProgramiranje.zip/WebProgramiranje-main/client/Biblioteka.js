export class Biblioteka
{
    constructor(ID, Ime, Adresa)
    {
        this.ID = ID;
        this.Ime = Ime;
        this.Adresa = Adresa;
    }
}
